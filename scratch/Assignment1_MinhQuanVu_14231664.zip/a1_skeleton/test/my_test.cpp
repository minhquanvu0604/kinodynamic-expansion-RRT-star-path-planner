#include "gtest/gtest.h"
#include <iostream>
#include <vector>
#include <algorithm>

//Student defined libraries
#include "../ackerman.h"
#include "pfms_types.h"
#include <cmath>


// Some helper header for assembling messages and testing
#include "a1_test_helper.h"
#include "ackerman_test.h"

TEST (MyFunctionTest, Test1){

}